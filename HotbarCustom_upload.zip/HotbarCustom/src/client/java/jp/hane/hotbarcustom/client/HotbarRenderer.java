package jp.hane.hotbarcustom.client;

import jp.hane.hotbarcustom.client.config.HotbarConfig;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElement;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import org.joml.Matrix3x2fStack;

/**
 * Custom hotbar + held-item-name HUD elements.
 * Installed by replacing the vanilla elements through Fabric's
 * HudElementRegistry, so no mixins are needed and the vanilla
 * element can be delegated to at any time (master switch OFF, or
 * name mode VANILLA).
 */
public final class HotbarRenderer {

	private static final Identifier HOTBAR_SPRITE = Identifier.fromNamespaceAndPath("minecraft", "hud/hotbar");
	private static final Identifier HOTBAR_SELECTION_SPRITE = Identifier.fromNamespaceAndPath("minecraft", "hud/hotbar_selection");

	private static final int CELL = 20;      // one slot cell (vanilla pitch)
	private static final int BAR_THICK = 22; // bar thickness incl. 1px padding both sides

	// selection tracking shared with the item-name element
	private static int lastSelectedSlot = -1;
	private static ItemStack lastSelectedStack = ItemStack.EMPTY;
	private static long lastSelectionChangeMillis = 0;

	private HotbarRenderer() {
	}

	// ================= geometry =================

	/** Final on-screen rectangle of the bar plus the local (unscaled) size. */
	public record BarRect(int x, int y, int w, int h, int localW, int localH, boolean vertical) {
		int centerX() {
			return x + w / 2;
		}
	}

	public static BarRect computeBar(HotbarConfig cfg, int guiWidth, int guiHeight) {
		int visible = cfg.visibleSlots;
		int pitch = CELL + cfg.slotGap;
		int content = visible * pitch - cfg.slotGap;
		boolean vertical = cfg.layout == HotbarConfig.Layout.LEFT || cfg.layout == HotbarConfig.Layout.RIGHT;
		boolean vanillaGeometry = !vertical && cfg.slotGap == 0 && visible == 9;
		int localW = vertical ? BAR_THICK : (vanillaGeometry ? 182 : content + 2);
		int localH = vertical ? content + 2 : BAR_THICK;
		float scale = cfg.scalePercent / 100.0f;
		int w = Math.round(localW * scale);
		int h = Math.round(localH * scale);
		int x;
		int y;
		switch (cfg.layout) {
			case BOTTOM -> {
				x = guiWidth / 2 + cfg.offsetX - w / 2;
				y = guiHeight + cfg.offsetY - h;
			}
			case TOP -> {
				x = guiWidth / 2 + cfg.offsetX - w / 2;
				y = cfg.offsetY;
			}
			case LEFT -> {
				x = cfg.offsetX;
				y = guiHeight / 2 + cfg.offsetY - h / 2;
			}
			case RIGHT -> {
				x = guiWidth + cfg.offsetX - w;
				y = guiHeight / 2 + cfg.offsetY - h / 2;
			}
			default -> {
				x = 0;
				y = 0;
			}
		}
		return new BarRect(x, y, w, h, localW, localH, vertical);
	}

	private static boolean vanillaGeometry(HotbarConfig cfg) {
		return (cfg.layout == HotbarConfig.Layout.BOTTOM || cfg.layout == HotbarConfig.Layout.TOP)
				&& cfg.slotGap == 0 && cfg.visibleSlots == 9;
	}

	// ================= hotbar element =================

	public static HudElement hotbarElement(HudElement original) {
		return (graphics, deltaTracker) -> {
			HotbarConfig cfg = HotbarConfig.get();
			if (!cfg.enabled) {
				original.extractRenderState(graphics, deltaTracker);
				return;
			}
			Minecraft mc = Minecraft.getInstance();
			LocalPlayer player = mc.player;
			if (player == null || player.isSpectator()) {
				return;
			}
			renderHotbar(graphics, mc, player, cfg);
		};
	}

	private static void renderHotbar(GuiGraphicsExtractor g, Minecraft mc, LocalPlayer player, HotbarConfig cfg) {
		Inventory inventory = player.getInventory();
		int selected = inventory.getSelectedSlot();

		// keep the shared selection state fresh for the name element
		ItemStack selectedStack = inventory.getSelectedItem();
		if (selected != lastSelectedSlot || !ItemStack.isSameItemSameComponents(selectedStack, lastSelectedStack)) {
			lastSelectedSlot = selected;
			lastSelectedStack = selectedStack;
			lastSelectionChangeMillis = System.currentTimeMillis();
		}

		int guiW = g.guiWidth();
		int guiH = g.guiHeight();
		BarRect bar = computeBar(cfg, guiW, guiH);
		float scale = cfg.scalePercent / 100.0f;
		int pitch = CELL + cfg.slotGap;
		int start = HotbarMath.windowStart(selected, cfg.visibleSlots);
		long now = System.currentTimeMillis();

		Matrix3x2fStack pose = g.pose();
		pose.pushMatrix();
		pose.translate(bar.x(), bar.y());
		pose.scale(scale, scale);
		try {
			drawBackground(g, cfg, bar, now);
			drawSelection(g, cfg, bar, selected, start, pitch, now);
			drawItems(g, mc, inventory, cfg, start, pitch);
			drawOffhand(g, mc, player, cfg, bar);
		} finally {
			pose.popMatrix();
		}

		drawAttackIndicator(g, player, cfg, bar, selected, start, pitch);
		drawInfoLine(g, mc, player, cfg, bar);
	}

	private static void drawBackground(GuiGraphicsExtractor g, HotbarConfig cfg, BarRect bar, long now) {
		boolean useVanillaSprite = cfg.backgroundStyle == HotbarConfig.BackgroundStyle.VANILLA && vanillaGeometry(cfg);
		if (useVanillaSprite) {
			g.blitSprite(RenderPipelines.GUI_TEXTURED, HOTBAR_SPRITE, 0, 0, 182, 22);
			return;
		}
		if (cfg.backgroundStyle == HotbarConfig.BackgroundStyle.NONE) {
			return;
		}
		// FLAT (also the fallback when VANILLA was picked with custom geometry)
		int rgb = cfg.rainbowBackground
				? HotbarMath.rainbowRgb(now, 6000)
				: HotbarMath.argb(255, cfg.bgRed, cfg.bgGreen, cfg.bgBlue) & 0xFFFFFF;
		int bgColor = HotbarMath.argb(cfg.bgAlpha, (rgb >> 16) & 0xFF, (rgb >> 8) & 0xFF, rgb & 0xFF);
		int borderColor = HotbarMath.argb(255, cfg.borderRed, cfg.borderGreen, cfg.borderBlue);
		g.fill(0, 0, bar.localW(), bar.localH(), bgColor);
		g.outline(0, 0, bar.localW(), bar.localH(), borderColor);
		// slot separators
		int pitch = CELL + cfg.slotGap;
		int sepColor = HotbarMath.argb(90, cfg.borderRed, cfg.borderGreen, cfg.borderBlue);
		for (int p = 1; p < cfg.visibleSlots; p++) {
			if (bar.vertical()) {
				int y = 1 + p * pitch - cfg.slotGap - 1;
				g.fill(1, y, bar.localW() - 1, y + 1, sepColor);
			} else {
				int x = 1 + p * pitch - cfg.slotGap - 1;
				g.fill(x, 1, x + 1, bar.localH() - 1, sepColor);
			}
		}
	}

	private static int cellX(BarRect bar, int pitch, int position) {
		return bar.vertical() ? 1 : 1 + position * pitch;
	}

	private static int cellY(BarRect bar, int pitch, int position) {
		return bar.vertical() ? 1 + position * pitch : 1;
	}

	private static void drawSelection(GuiGraphicsExtractor g, HotbarConfig cfg, BarRect bar,
									  int selected, int start, int pitch, long now) {
		int position = selected - start;
		if (position < 0 || position >= cfg.visibleSlots) {
			return;
		}
		int cx = cellX(bar, pitch, position);
		int cy = cellY(bar, pitch, position);
		int rgb = cfg.rainbowSelection
				? HotbarMath.rainbowRgb(now, 3000)
				: HotbarMath.argb(255, cfg.selRed, cfg.selGreen, cfg.selBlue) & 0xFFFFFF;
		int r = (rgb >> 16) & 0xFF;
		int gg = (rgb >> 8) & 0xFF;
		int b = rgb & 0xFF;

		HotbarConfig.SelectionStyle style = cfg.selectionStyle;
		if (style == HotbarConfig.SelectionStyle.VANILLA && vanillaGeometry(cfg)) {
			g.blitSprite(RenderPipelines.GUI_TEXTURED, HOTBAR_SELECTION_SPRITE, cx - 1, cy - 1, 24, 23);
			return;
		}
		if (style == HotbarConfig.SelectionStyle.VANILLA) {
			style = HotbarConfig.SelectionStyle.OUTLINE; // fallback for custom geometry
		}
		switch (style) {
			case OUTLINE -> {
				g.outline(cx - 1, cy - 1, 22, 22, HotbarMath.argb(255, r, gg, b));
				g.outline(cx - 2, cy - 2, 24, 24, HotbarMath.argb(110, r, gg, b));
			}
			case GLOW -> {
				int alpha = HotbarMath.pulseAlpha(now);
				g.fill(cx - 2, cy - 2, cx + 22, cy + 22, HotbarMath.argb(alpha / 3, r, gg, b));
				g.outline(cx - 1, cy - 1, 22, 22, HotbarMath.argb(alpha, r, gg, b));
				g.outline(cx - 2, cy - 2, 24, 24, HotbarMath.argb(alpha / 2, r, gg, b));
			}
			case UNDERLINE -> {
				if (bar.vertical()) {
					g.fill(cx + 20, cy, cx + 22, cy + 20, HotbarMath.argb(255, r, gg, b));
				} else {
					g.fill(cx, cy + 20, cx + 20, cy + 22, HotbarMath.argb(255, r, gg, b));
				}
			}
			default -> {
			}
		}
	}

	private static void drawItems(GuiGraphicsExtractor g, Minecraft mc, Inventory inventory,
								  HotbarConfig cfg, int start, int pitch) {
		BarRect dummy = new BarRect(0, 0, 0, 0, 0, 0,
				cfg.layout == HotbarConfig.Layout.LEFT || cfg.layout == HotbarConfig.Layout.RIGHT);
		Font font = mc.font;
		for (int p = 0; p < cfg.visibleSlots; p++) {
			int slot = start + p;
			if (slot > 8) break;
			int cx = cellX(dummy, pitch, p);
			int cy = cellY(dummy, pitch, p);
			ItemStack stack = inventory.getItem(slot);
			if (!stack.isEmpty()) {
				g.item(stack, cx + 2, cy + 2);
				g.itemDecorations(font, stack, cx + 2, cy + 2);
			}
			if (cfg.showSlotNumbers) {
				g.text(font, String.valueOf(slot + 1), cx + 2, cy + 1, 0xFFFFFFFF, true);
			}
		}
	}

	private static void drawOffhand(GuiGraphicsExtractor g, Minecraft mc, LocalPlayer player,
									HotbarConfig cfg, BarRect bar) {
		ItemStack offhand = player.getOffhandItem();
		if (offhand.isEmpty()) {
			return;
		}
		// a single mini cell next to the bar (left for horizontal, above for vertical)
		int ox;
		int oy;
		if (bar.vertical()) {
			ox = 0;
			oy = -24;
		} else {
			ox = -24;
			oy = 0;
		}
		if (cfg.backgroundStyle != HotbarConfig.BackgroundStyle.NONE) {
			int bgColor = HotbarMath.argb(cfg.bgAlpha, cfg.bgRed, cfg.bgGreen, cfg.bgBlue);
			int borderColor = HotbarMath.argb(255, cfg.borderRed, cfg.borderGreen, cfg.borderBlue);
			g.fill(ox, oy, ox + 22, oy + 22, bgColor);
			g.outline(ox, oy, 22, 22, borderColor);
		}
		g.item(offhand, ox + 3, oy + 3);
		g.itemDecorations(mc.font, offhand, ox + 3, oy + 3);
	}

	private static void drawAttackIndicator(GuiGraphicsExtractor g, LocalPlayer player,
											HotbarConfig cfg, BarRect bar, int selected, int start, int pitch) {
		float strength = player.getAttackStrengthScale(0.0f);
		if (strength >= 1.0f) {
			return;
		}
		float scale = cfg.scalePercent / 100.0f;
		int position = selected - start;
		if (position < 0 || position >= cfg.visibleSlots) {
			return;
		}
		int cellW = Math.round((CELL) * scale);
		int cx;
		int cy;
		int w;
		if (bar.vertical()) {
			cx = bar.x();
			cy = bar.y() + Math.round((1 + position * pitch) * scale);
			w = Math.round(BAR_THICK * scale);
			int h = Math.max(1, Math.round(CELL * scale * strength));
			g.fill(cx + w + 1, cy, cx + w + 3, cy + h, HotbarMath.argb(220, cfg.selRed, cfg.selGreen, cfg.selBlue));
		} else {
			cx = bar.x() + Math.round((1 + position * pitch) * scale);
			w = Math.max(1, Math.round(CELL * scale * strength));
			cy = bar.y() + bar.h();
			g.fill(cx, cy + 1, cx + w, cy + 3, HotbarMath.argb(220, cfg.selRed, cfg.selGreen, cfg.selBlue));
		}
	}

	private static void drawInfoLine(GuiGraphicsExtractor g, Minecraft mc, LocalPlayer player,
									 HotbarConfig cfg, BarRect bar) {
		if (!cfg.infoFps && !cfg.infoCoords && !cfg.infoTime) {
			return;
		}
		StringBuilder sb = new StringBuilder();
		if (cfg.infoFps) {
			sb.append("FPS: ").append(mc.getFps());
		}
		if (cfg.infoCoords) {
			if (sb.length() > 0) sb.append(" | ");
			net.minecraft.world.phys.Vec3 pos = player.getPosition(1.0f);
			sb.append("XYZ: ")
					.append((int) Math.floor(pos.x)).append(" / ")
					.append((int) Math.floor(pos.y)).append(" / ")
					.append((int) Math.floor(pos.z));
		}
		if (cfg.infoTime && mc.level != null) {
			if (sb.length() > 0) sb.append(" | ");
			long dayTime = mc.level.getOverworldClockTime();
			sb.append("Day ").append(dayTime / 24000 + 1).append(" ").append(HotbarMath.gameClock(dayTime));
		}
		if (sb.length() == 0) {
			return;
		}
		String text = sb.toString();
		Font font = mc.font;
		int y = cfg.layout == HotbarConfig.Layout.TOP ? bar.y() + bar.h() + 3 : bar.y() - 11;
		if (bar.vertical()) {
			g.text(font, text, bar.x(), y, 0xFFFFFFFF, true);
		} else {
			g.centeredText(font, text, bar.centerX(), y, 0xFFFFFFFF);
		}
	}

	// ================= held item name element =================

	public static HudElement heldItemNameElement(HudElement original) {
		return (graphics, deltaTracker) -> {
			HotbarConfig cfg = HotbarConfig.get();
			if (!cfg.enabled || cfg.nameMode == HotbarConfig.NameMode.VANILLA) {
				original.extractRenderState(graphics, deltaTracker);
				return;
			}
			if (cfg.nameMode == HotbarConfig.NameMode.OFF) {
				return;
			}
			Minecraft mc = Minecraft.getInstance();
			LocalPlayer player = mc.player;
			if (player == null || player.isSpectator()) {
				return;
			}
			ItemStack stack = player.getInventory().getSelectedItem();
			if (stack.isEmpty()) {
				return;
			}
			int alpha = 255;
			if (cfg.nameMode == HotbarConfig.NameMode.CUSTOM) {
				long elapsed = System.currentTimeMillis() - lastSelectionChangeMillis;
				long limit = cfg.nameSeconds * 1000L;
				if (elapsed > limit) {
					return;
				}
				long remain = limit - elapsed;
				if (remain < 400) {
					alpha = (int) (255 * remain / 400);
				}
				if (alpha < 8) {
					return;
				}
			}
			BarRect bar = computeBar(cfg, graphics.guiWidth(), graphics.guiHeight());
			int y = cfg.layout == HotbarConfig.Layout.TOP ? bar.y() + bar.h() + 14 : bar.y() - 24;
			int color = HotbarMath.argb(alpha, cfg.nameRed, cfg.nameGreen, cfg.nameBlue);
			Component name = stack.getHoverName();
			graphics.centeredText(mc.font, name, bar.centerX(), y, color);
		};
	}
}
