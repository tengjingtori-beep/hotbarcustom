package jp.hane.hotbarcustom.client.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * All user settings for the hotbar, persisted as JSON in
 * config/hotbarcustom.json. Plain data only; rendering reads it live,
 * so changes made in the config screen apply immediately.
 */
public class HotbarConfig {

	public enum Layout { BOTTOM, TOP, LEFT, RIGHT }

	public enum BackgroundStyle { VANILLA, FLAT, NONE }

	public enum SelectionStyle { VANILLA, OUTLINE, GLOW, UNDERLINE }

	public enum NameMode { VANILLA, CUSTOM, ALWAYS, OFF }

	// ---- master ----
	public boolean enabled = true;

	// ---- placement ----
	public Layout layout = Layout.BOTTOM;
	public int offsetX = 0;          // -200..200
	public int offsetY = 0;          // -200..200
	public int scalePercent = 100;   // 50..200
	public int slotGap = 0;          // 0..8 (extra px between slots)
	public int visibleSlots = 9;     // 1..9 (display window; inventory is untouched)

	// ---- background ----
	public BackgroundStyle backgroundStyle = BackgroundStyle.VANILLA;
	public int bgRed = 0;
	public int bgGreen = 0;
	public int bgBlue = 0;
	public int bgAlpha = 160;        // 0..255
	public int borderRed = 255;
	public int borderGreen = 255;
	public int borderBlue = 255;
	public boolean rainbowBackground = false;

	// ---- selection highlight ----
	public SelectionStyle selectionStyle = SelectionStyle.VANILLA;
	public int selRed = 255;
	public int selGreen = 220;
	public int selBlue = 0;
	public boolean rainbowSelection = false;

	// ---- held item name ----
	public NameMode nameMode = NameMode.CUSTOM;
	public int nameSeconds = 3;      // 1..10, used by NameMode.CUSTOM
	public int nameRed = 255;
	public int nameGreen = 255;
	public int nameBlue = 255;

	// ---- extras ----
	public boolean showSlotNumbers = false;
	public boolean infoFps = false;
	public boolean infoCoords = false;
	public boolean infoTime = false;

	// ---- user presets: slot name -> JSON snapshot of this config ----
	public Map<String, String> customPresets = new LinkedHashMap<>();

	// ================= persistence =================

	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
	private static HotbarConfig instance;

	public static Path configPath() {
		return FabricLoader.getInstance().getConfigDir().resolve("hotbarcustom.json");
	}

	public static HotbarConfig get() {
		if (instance == null) {
			instance = load();
		}
		return instance;
	}

	private static HotbarConfig load() {
		Path path = configPath();
		if (Files.isRegularFile(path)) {
			try (Reader reader = Files.newBufferedReader(path)) {
				HotbarConfig loaded = GSON.fromJson(reader, HotbarConfig.class);
				if (loaded != null) {
					loaded.sanitize();
					return loaded;
				}
			} catch (Exception e) {
				System.err.println("[hotbarcustom] Could not read config, using defaults: " + e);
			}
		}
		HotbarConfig fresh = new HotbarConfig();
		fresh.save();
		return fresh;
	}

	public void save() {
		try {
			Path path = configPath();
			Files.createDirectories(path.getParent());
			try (Writer writer = Files.newBufferedWriter(path)) {
				GSON.toJson(this, writer);
			}
		} catch (IOException e) {
			System.err.println("[hotbarcustom] Could not save config: " + e);
		}
	}

	/** Clamp every value into its valid range (protects against hand-edited JSON). */
	public void sanitize() {
		if (layout == null) layout = Layout.BOTTOM;
		if (backgroundStyle == null) backgroundStyle = BackgroundStyle.VANILLA;
		if (selectionStyle == null) selectionStyle = SelectionStyle.VANILLA;
		if (nameMode == null) nameMode = NameMode.CUSTOM;
		offsetX = clamp(offsetX, -200, 200);
		offsetY = clamp(offsetY, -200, 200);
		scalePercent = clamp(scalePercent, 50, 200);
		slotGap = clamp(slotGap, 0, 8);
		visibleSlots = clamp(visibleSlots, 1, 9);
		bgRed = clamp(bgRed, 0, 255);
		bgGreen = clamp(bgGreen, 0, 255);
		bgBlue = clamp(bgBlue, 0, 255);
		bgAlpha = clamp(bgAlpha, 0, 255);
		borderRed = clamp(borderRed, 0, 255);
		borderGreen = clamp(borderGreen, 0, 255);
		borderBlue = clamp(borderBlue, 0, 255);
		selRed = clamp(selRed, 0, 255);
		selGreen = clamp(selGreen, 0, 255);
		selBlue = clamp(selBlue, 0, 255);
		nameSeconds = clamp(nameSeconds, 1, 10);
		nameRed = clamp(nameRed, 0, 255);
		nameGreen = clamp(nameGreen, 0, 255);
		nameBlue = clamp(nameBlue, 0, 255);
		if (customPresets == null) customPresets = new LinkedHashMap<>();
	}

	private static int clamp(int v, int min, int max) {
		return Math.max(min, Math.min(max, v));
	}

	// ================= presets =================

	/** Snapshot of the visual settings (everything except customPresets itself). */
	public String snapshotJson() {
		JsonObject obj = (JsonObject) GSON.toJsonTree(this);
		obj.remove("customPresets");
		return GSON.toJson(obj);
	}

	/** Apply a snapshot produced by snapshotJson(). Keeps current customPresets. */
	public void applySnapshot(String json) {
		try {
			HotbarConfig parsed = GSON.fromJson(JsonParser.parseString(json), HotbarConfig.class);
			if (parsed == null) return;
			Map<String, String> keep = this.customPresets;
			parsed.customPresets = keep;
			parsed.sanitize();
			copyFrom(parsed);
		} catch (Exception e) {
			System.err.println("[hotbarcustom] Bad preset data: " + e);
		}
	}

	private void copyFrom(HotbarConfig o) {
		this.enabled = o.enabled;
		this.layout = o.layout;
		this.offsetX = o.offsetX;
		this.offsetY = o.offsetY;
		this.scalePercent = o.scalePercent;
		this.slotGap = o.slotGap;
		this.visibleSlots = o.visibleSlots;
		this.backgroundStyle = o.backgroundStyle;
		this.bgRed = o.bgRed;
		this.bgGreen = o.bgGreen;
		this.bgBlue = o.bgBlue;
		this.bgAlpha = o.bgAlpha;
		this.borderRed = o.borderRed;
		this.borderGreen = o.borderGreen;
		this.borderBlue = o.borderBlue;
		this.rainbowBackground = o.rainbowBackground;
		this.selectionStyle = o.selectionStyle;
		this.selRed = o.selRed;
		this.selGreen = o.selGreen;
		this.selBlue = o.selBlue;
		this.rainbowSelection = o.rainbowSelection;
		this.nameMode = o.nameMode;
		this.nameSeconds = o.nameSeconds;
		this.nameRed = o.nameRed;
		this.nameGreen = o.nameGreen;
		this.nameBlue = o.nameBlue;
		this.showSlotNumbers = o.showSlotNumbers;
		this.infoFps = o.infoFps;
		this.infoCoords = o.infoCoords;
		this.infoTime = o.infoTime;
	}

	/** Built-in presets, as snapshots applied on top of a default config. */
	public static HotbarConfig builtinPreset(String name) {
		HotbarConfig c = new HotbarConfig();
		switch (name) {
			case "minimal" -> {
				c.backgroundStyle = BackgroundStyle.NONE;
				c.selectionStyle = SelectionStyle.UNDERLINE;
				c.selRed = 255; c.selGreen = 255; c.selBlue = 255;
			}
			case "big" -> {
				c.scalePercent = 150;
			}
			case "left" -> {
				c.layout = Layout.LEFT;
				c.backgroundStyle = BackgroundStyle.FLAT;
			}
			case "right" -> {
				c.layout = Layout.RIGHT;
				c.backgroundStyle = BackgroundStyle.FLAT;
			}
			case "rainbow" -> {
				c.backgroundStyle = BackgroundStyle.FLAT;
				c.selectionStyle = SelectionStyle.GLOW;
				c.rainbowBackground = true;
				c.rainbowSelection = true;
			}
			case "night" -> {
				c.backgroundStyle = BackgroundStyle.FLAT;
				c.bgRed = 10; c.bgGreen = 10; c.bgBlue = 30; c.bgAlpha = 200;
				c.borderRed = 80; c.borderGreen = 80; c.borderBlue = 160;
				c.selectionStyle = SelectionStyle.OUTLINE;
				c.selRed = 120; c.selGreen = 180; c.selBlue = 255;
				c.nameRed = 180; c.nameGreen = 200; c.nameBlue = 255;
			}
			default -> {
				// "standard": plain defaults
			}
		}
		c.sanitize();
		return c;
	}

	public void applyBuiltin(String name) {
		HotbarConfig preset = builtinPreset(name);
		Map<String, String> keep = this.customPresets;
		preset.customPresets = keep;
		copyFrom(preset);
		this.customPresets = keep;
	}
}
