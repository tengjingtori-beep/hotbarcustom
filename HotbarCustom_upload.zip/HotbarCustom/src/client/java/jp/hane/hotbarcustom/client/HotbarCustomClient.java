package jp.hane.hotbarcustom.client;

import com.mojang.blaze3d.platform.InputConstants;
import jp.hane.hotbarcustom.client.config.HotbarConfig;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.KeyMapping;
import net.minecraft.resources.Identifier;
import org.lwjgl.glfw.GLFW;

public class HotbarCustomClient implements ClientModInitializer {

	private static KeyMapping openConfigKey;

	@Override
	public void onInitializeClient() {
		// Load (or create) the config file first.
		HotbarConfig.get();

		openConfigKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
				"key.hotbarcustom.open_config",
				InputConstants.Type.KEYBOARD,
				GLFW.GLFW_KEY_H,
				KeyMapping.Category.register(Identifier.fromNamespaceAndPath("hotbarcustom", "main"))));

		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			while (openConfigKey.consumeClick()) {
				client.setScreenAndShow(new HotbarConfigScreen());
			}
		});

		// Replace the vanilla hotbar and held-item-name elements with ours.
		// The original elements are kept so the mod can delegate back to
		// vanilla whenever the user wants the stock look.
		HudElementRegistry.replaceElement(VanillaHudElements.HOTBAR,
				original -> HotbarRenderer.hotbarElement(original));
		HudElementRegistry.replaceElement(VanillaHudElements.HELD_ITEM_TOOLTIP,
				original -> HotbarRenderer.heldItemNameElement(original));
	}
}
