package jp.hane.hotbarcustom.client;

import jp.hane.hotbarcustom.client.config.HotbarConfig;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.CycleButton;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.function.BooleanSupplier;
import java.util.function.IntConsumer;

/**
 * In-game settings screen for the hotbar mod.
 * Five pages: 配置 / 背景 / 選択・名前 / 表示 / プリセット.
 * Every change is saved to the config file immediately and the
 * renderer reads the config live, so the hotbar behind the screen
 * updates as you tweak.
 */
public class HotbarConfigScreen extends Screen {

	private static final int CONTENT_W = 320;
	private static final int ROW_H = 23;

	private int page = 0;
	// color preview swatches (page-local coordinates set while building)
	private int bgPreviewX = -1;
	private int bgPreviewY = -1;
	private int selPreviewX = -1;
	private int selPreviewY = -1;

	public HotbarConfigScreen() {
		super(Component.translatable("screen.hotbarcustom.title"));
	}

	private HotbarConfig cfg() {
		return HotbarConfig.get();
	}

	private int x0() {
		return (this.width - CONTENT_W) / 2;
	}

	@Override
	protected void init() {
		bgPreviewX = -1;
		selPreviewX = -1;
		int x = x0();
		// page tabs
		String[] pageKeys = {
				"gui.hotbarcustom.page.placement",
				"gui.hotbarcustom.page.background",
				"gui.hotbarcustom.page.selection",
				"gui.hotbarcustom.page.display",
				"gui.hotbarcustom.page.presets",
		};
		int tabW = CONTENT_W / pageKeys.length;
		for (int i = 0; i < pageKeys.length; i++) {
			final int target = i;
			Button tab = Button.builder(Component.translatable(pageKeys[i]), b -> {
						if (this.page != target) {
							this.page = target;
							this.clearWidgets();
							this.init();
						}
					})
					.bounds(x + i * tabW, 24, tabW - 2, 20)
					.build();
			tab.active = (i != this.page);
			this.addRenderableWidget(tab);
		}
		// done button
		this.addRenderableWidget(Button.builder(Component.translatable("gui.done"), b -> this.onClose())
				.bounds(this.width / 2 - 100, this.height - 28, 200, 20)
				.build());

		switch (this.page) {
			case 0 -> buildPlacement(x, 54);
			case 1 -> buildBackground(x, 54);
			case 2 -> buildSelection(x, 54);
			case 3 -> buildDisplay(x, 54);
			case 4 -> buildPresets(x, 54);
			default -> {
			}
		}
	}

	// ================= widget helpers =================

	private static class IntSlider extends AbstractSliderButton {
		private final int min;
		private final int max;
		private final Component label;
		private final IntConsumer onChange;

		IntSlider(int x, int y, int w, Component label, int min, int max, int initial, IntConsumer onChange) {
			super(x, y, w, 20, Component.empty(), (initial - min) / (double) (max - min));
			this.min = min;
			this.max = max;
			this.label = label;
			this.onChange = onChange;
			this.updateMessage();
		}

		private int current() {
			return min + (int) Math.round(this.value * (max - min));
		}

		@Override
		protected void updateMessage() {
			this.setMessage(Component.empty().append(this.label).append(": " + current()));
		}

		@Override
		protected void applyValue() {
			this.onChange.accept(current());
		}
	}

	private IntSlider slider(int x, int y, int w, String labelKey, int min, int max, int initial, IntConsumer setter) {
		IntSlider s = new IntSlider(x, y, w, Component.translatable(labelKey), min, max, initial,
				v -> {
					setter.accept(v);
					cfg().save();
				});
		this.addRenderableWidget(s);
		return s;
	}

	private IntSlider rgbSlider(int x, int y, int w, String letter, int initial, IntConsumer setter) {
		IntSlider s = new IntSlider(x, y, w, Component.literal(letter), 0, 255, initial,
				v -> {
					setter.accept(v);
					cfg().save();
				});
		this.addRenderableWidget(s);
		return s;
	}

	private Button toggle(int x, int y, int w, String labelKey, BooleanSupplier get, Runnable flip) {
		Button b = Button.builder(toggleMessage(labelKey, get.getAsBoolean()), btn -> {
					flip.run();
					cfg().save();
					btn.setMessage(toggleMessage(labelKey, get.getAsBoolean()));
				})
				.bounds(x, y, w, 20)
				.build();
		this.addRenderableWidget(b);
		return b;
	}

	private static Component toggleMessage(String labelKey, boolean on) {
		return Component.translatable(labelKey)
				.append(": ")
				.append(Component.translatable(on ? "gui.hotbarcustom.on" : "gui.hotbarcustom.off"));
	}

	// ================= pages =================

	private void buildPlacement(int x, int y) {
		HotbarConfig cfg = cfg();
		this.addRenderableWidget(CycleButton.builder(
						(HotbarConfig.Layout v) -> Component.translatable("option.hotbarcustom.layout." + v.name().toLowerCase()),
						cfg.layout)
				.withValues(HotbarConfig.Layout.values())
				.create(x, y, CONTENT_W, 20, Component.translatable("option.hotbarcustom.layout"),
						(btn, v) -> {
							cfg.layout = v;
							cfg.save();
						}));
		y += ROW_H;
		slider(x, y, CONTENT_W, "option.hotbarcustom.scale", 50, 200, cfg.scalePercent, v -> cfg.scalePercent = v);
		y += ROW_H;
		slider(x, y, CONTENT_W, "option.hotbarcustom.offset_x", -200, 200, cfg.offsetX, v -> cfg.offsetX = v);
		y += ROW_H;
		slider(x, y, CONTENT_W, "option.hotbarcustom.offset_y", -200, 200, cfg.offsetY, v -> cfg.offsetY = v);
		y += ROW_H;
		int half = (CONTENT_W - 4) / 2;
		slider(x, y, half, "option.hotbarcustom.slot_gap", 0, 8, cfg.slotGap, v -> cfg.slotGap = v);
		slider(x + half + 4, y, half, "option.hotbarcustom.visible_slots", 1, 9, cfg.visibleSlots, v -> cfg.visibleSlots = v);
	}

	private void buildBackground(int x, int y) {
		HotbarConfig cfg = cfg();
		this.addRenderableWidget(CycleButton.builder(
						(HotbarConfig.BackgroundStyle v) -> Component.translatable("option.hotbarcustom.background_style." + v.name().toLowerCase()),
						cfg.backgroundStyle)
				.withValues(HotbarConfig.BackgroundStyle.values())
				.create(x, y, CONTENT_W, 20, Component.translatable("option.hotbarcustom.background_style"),
						(btn, v) -> {
							cfg.backgroundStyle = v;
							cfg.save();
						}));
		y += ROW_H;
		int third = (CONTENT_W - 8) / 3;
		rgbSlider(x, y, third, "R", cfg.bgRed, v -> cfg.bgRed = v);
		rgbSlider(x + third + 4, y, third, "G", cfg.bgGreen, v -> cfg.bgGreen = v);
		rgbSlider(x + 2 * third + 8, y, third, "B", cfg.bgBlue, v -> cfg.bgBlue = v);
		y += ROW_H;
		slider(x, y, CONTENT_W, "option.hotbarcustom.bg_alpha", 0, 255, cfg.bgAlpha, v -> cfg.bgAlpha = v);
		y += ROW_H;
		rgbSlider(x, y, third, "R", cfg.borderRed, v -> cfg.borderRed = v);
		rgbSlider(x + third + 4, y, third, "G", cfg.borderGreen, v -> cfg.borderGreen = v);
		rgbSlider(x + 2 * third + 8, y, third, "B", cfg.borderBlue, v -> cfg.borderBlue = v);
		y += ROW_H;
		toggle(x, y, CONTENT_W - 80, "option.hotbarcustom.rainbow_background",
				() -> cfg.rainbowBackground, () -> cfg.rainbowBackground = !cfg.rainbowBackground);
		bgPreviewX = x + CONTENT_W - 72;
		bgPreviewY = y;
	}

	private void buildSelection(int x, int y) {
		HotbarConfig cfg = cfg();
		this.addRenderableWidget(CycleButton.builder(
						(HotbarConfig.SelectionStyle v) -> Component.translatable("option.hotbarcustom.selection_style." + v.name().toLowerCase()),
						cfg.selectionStyle)
				.withValues(HotbarConfig.SelectionStyle.values())
				.create(x, y, CONTENT_W, 20, Component.translatable("option.hotbarcustom.selection_style"),
						(btn, v) -> {
							cfg.selectionStyle = v;
							cfg.save();
						}));
		y += ROW_H;
		int third = (CONTENT_W - 8) / 3;
		rgbSlider(x, y, third, "R", cfg.selRed, v -> cfg.selRed = v);
		rgbSlider(x + third + 4, y, third, "G", cfg.selGreen, v -> cfg.selGreen = v);
		rgbSlider(x + 2 * third + 8, y, third, "B", cfg.selBlue, v -> cfg.selBlue = v);
		y += ROW_H;
		toggle(x, y, CONTENT_W - 80, "option.hotbarcustom.rainbow_selection",
				() -> cfg.rainbowSelection, () -> cfg.rainbowSelection = !cfg.rainbowSelection);
		selPreviewX = x + CONTENT_W - 72;
		selPreviewY = y;
		y += ROW_H;
		this.addRenderableWidget(CycleButton.builder(
						(HotbarConfig.NameMode v) -> Component.translatable("option.hotbarcustom.name_mode." + v.name().toLowerCase()),
						cfg.nameMode)
				.withValues(HotbarConfig.NameMode.values())
				.create(x, y, CONTENT_W, 20, Component.translatable("option.hotbarcustom.name_mode"),
						(btn, v) -> {
							cfg.nameMode = v;
							cfg.save();
						}));
		y += ROW_H;
		slider(x, y, CONTENT_W, "option.hotbarcustom.name_seconds", 1, 10, cfg.nameSeconds, v -> cfg.nameSeconds = v);
		y += ROW_H;
		rgbSlider(x, y, third, "R", cfg.nameRed, v -> cfg.nameRed = v);
		rgbSlider(x + third + 4, y, third, "G", cfg.nameGreen, v -> cfg.nameGreen = v);
		rgbSlider(x + 2 * third + 8, y, third, "B", cfg.nameBlue, v -> cfg.nameBlue = v);
	}

	private void buildDisplay(int x, int y) {
		HotbarConfig cfg = cfg();
		toggle(x, y, CONTENT_W, "option.hotbarcustom.enabled", () -> cfg.enabled, () -> cfg.enabled = !cfg.enabled);
		y += ROW_H;
		toggle(x, y, CONTENT_W, "option.hotbarcustom.show_slot_numbers",
				() -> cfg.showSlotNumbers, () -> cfg.showSlotNumbers = !cfg.showSlotNumbers);
		y += ROW_H;
		int half = (CONTENT_W - 4) / 2;
		toggle(x, y, half, "option.hotbarcustom.info_fps", () -> cfg.infoFps, () -> cfg.infoFps = !cfg.infoFps);
		toggle(x + half + 4, y, half, "option.hotbarcustom.info_coords", () -> cfg.infoCoords, () -> cfg.infoCoords = !cfg.infoCoords);
		y += ROW_H;
		toggle(x, y, CONTENT_W, "option.hotbarcustom.info_time", () -> cfg.infoTime, () -> cfg.infoTime = !cfg.infoTime);
	}

	private void buildPresets(int x, int y) {
		HotbarConfig cfg = cfg();
		String[] names = {"standard", "minimal", "big", "left", "right", "rainbow", "night"};
		int half = (CONTENT_W - 4) / 2;
		for (int i = 0; i < names.length; i++) {
			String name = names[i];
			int bx = x + (i % 2) * (half + 4);
			int by = y + (i / 2) * ROW_H;
			this.addRenderableWidget(Button.builder(Component.translatable("preset.hotbarcustom." + name), b -> {
						cfg.applyBuiltin(name);
						cfg.save();
						this.clearWidgets();
						this.init();
					})
					.bounds(bx, by, half, 20)
					.build());
		}
		y += ((names.length + 1) / 2) * ROW_H + 4;
		for (int slot = 1; slot <= 3; slot++) {
			String key = "custom" + slot;
			this.addRenderableWidget(Button.builder(Component.translatable("gui.hotbarcustom.preset.save", slot), b -> {
						cfg.customPresets.put(key, cfg.snapshotJson());
						cfg.save();
						this.clearWidgets();
						this.init();
					})
					.bounds(x, y, half, 20)
					.build());
			Button load = Button.builder(Component.translatable("gui.hotbarcustom.preset.load", slot), b -> {
						String json = cfg.customPresets.get(key);
						if (json != null) {
							cfg.applySnapshot(json);
							cfg.save();
							this.clearWidgets();
							this.init();
						}
					})
					.bounds(x + half + 4, y, half, 20)
					.build();
			load.active = cfg.customPresets.containsKey(key);
			this.addRenderableWidget(load);
			y += ROW_H;
		}
		this.addRenderableWidget(Button.builder(Component.translatable("gui.hotbarcustom.reset"), b -> {
					cfg.applyBuiltin("standard");
					cfg.save();
					this.clearWidgets();
					this.init();
				})
				.bounds(x, y, CONTENT_W, 20)
				.build());
	}

	// ================= rendering =================

	@Override
	public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTick) {
		super.extractRenderState(graphics, mouseX, mouseY, partialTick);
		graphics.centeredText(this.font, this.title, this.width / 2, 8, 0xFFFFFFFF);
		HotbarConfig cfg = cfg();
		if (bgPreviewX >= 0) {
			int color = HotbarMath.argb(cfg.bgAlpha, cfg.bgRed, cfg.bgGreen, cfg.bgBlue);
			graphics.fill(bgPreviewX, bgPreviewY, bgPreviewX + 72, bgPreviewY + 20, color);
			graphics.outline(bgPreviewX, bgPreviewY, 72, 20,
					HotbarMath.argb(255, cfg.borderRed, cfg.borderGreen, cfg.borderBlue));
		}
		if (selPreviewX >= 0) {
			int color = HotbarMath.argb(255, cfg.selRed, cfg.selGreen, cfg.selBlue);
			graphics.fill(selPreviewX, selPreviewY, selPreviewX + 72, selPreviewY + 20, color);
		}
		if (this.page == 1) {
			graphics.text(this.font, Component.translatable("gui.hotbarcustom.hint.background"),
					x0(), this.height - 52, 0xFFAAAAAA);
		}
	}

	@Override
	public void onClose() {
		cfg().save();
		super.onClose();
	}
}
