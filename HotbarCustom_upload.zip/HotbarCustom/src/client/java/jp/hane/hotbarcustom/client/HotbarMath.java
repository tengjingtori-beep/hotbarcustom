package jp.hane.hotbarcustom.client;

/**
 * Pure helper math for the hotbar renderer and the info line.
 * No Minecraft imports, so this class is unit-testable on its own.
 */
public final class HotbarMath {

	private HotbarMath() {
	}

	/**
	 * First visible slot index of the display window.
	 * The window shows {@code visible} of the 9 slots and follows the
	 * selection so the selected slot is always inside the window.
	 */
	public static int windowStart(int selected, int visible) {
		if (visible >= 9) return 0;
		int start = selected - visible + 1;
		if (start < 0) start = 0;
		int max = 9 - visible;
		if (start > max) start = max;
		if (selected < start) start = selected;
		return start;
	}

	/** Pack ARGB for GuiGraphicsExtractor.fill/outline. */
	public static int argb(int alpha, int red, int green, int blue) {
		return ((alpha & 0xFF) << 24) | ((red & 0xFF) << 16) | ((green & 0xFF) << 8) | (blue & 0xFF);
	}

	/** Rainbow color (RGB packed, no alpha) cycling with time. */
	public static int rainbowRgb(long timeMillis, int periodMillis) {
		float hue = (timeMillis % periodMillis) / (float) periodMillis;
		return java.awt.Color.HSBtoRGB(hue, 0.65f, 1.0f) & 0xFFFFFF;
	}

	/** Split a packed RGB value into {r, g, b}. */
	public static int[] unpackRgb(int rgb) {
		return new int[]{(rgb >> 16) & 0xFF, (rgb >> 8) & 0xFF, rgb & 0xFF};
	}

	/**
	 * Minecraft day time (0..23999 per day) to "HH:MM".
	 * Tick 0 is 06:00 in game time.
	 */
	public static String gameClock(long dayTime) {
		long t = ((dayTime % 24000) + 24000) % 24000;
		int hours = (int) ((t / 1000 + 6) % 24);
		int minutes = (int) ((t % 1000) * 60 / 1000);
		return String.format("%02d:%02d", hours, minutes);
	}

	/** Pulsing alpha 0..255 for the GLOW selection style. */
	public static int pulseAlpha(long timeMillis) {
		double wave = (Math.sin(timeMillis / 280.0) + 1.0) / 2.0; // 0..1
		return (int) (140 + wave * 115);
	}
}
